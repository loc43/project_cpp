#pragma once
#include <list>
#include <vector>
#include <functional>
#include <type_traits>

template <class KeyT>
class UnorderedSet {
 public:
  size_t n_buckets_ = 0;
  size_t n_elements_ = 0;
  std::vector<std::list<KeyT>> vector_;
  std::hash<KeyT> hash;

  UnorderedSet() : vector_(std::vector<std::list<KeyT>>()) {
    n_buckets_ = 0;
    n_elements_ = 0;
  }

  ~UnorderedSet() = default;

  explicit UnorderedSet(const size_t count) : vector_(std::vector<std::list<KeyT>>()) {
    n_buckets_ = count;
    n_elements_ = 0;
    vector_.resize(count);
  }

  template <class Iterator, class = std::enable_if_t<std::is_base_of_v<
                                std::forward_iterator_tag, typename std::iterator_traits<Iterator>::iterator_category>>>
  UnorderedSet(const Iterator first, const Iterator last) {
    auto iterator = first;
    while (iterator != last) {
      ++n_buckets_;
      ++n_elements_;
      ++iterator;
    }
    vector_.resize(n_buckets_);
    iterator = first;
    while (iterator != last) {
      auto idx = hash(*iterator) % n_buckets_;
      vector_[idx].push_front(*iterator);
      ++iterator;
    }
  }

  UnorderedSet(const UnorderedSet<KeyT>& other) {
    n_buckets_ = other.n_buckets_;
    vector_ = other.vector_;
    n_elements_ = other.n_elements_;
  }

  UnorderedSet& operator=(const UnorderedSet& other) {
    n_buckets_ = other.n_buckets_;
    n_elements_ = other.n_elements_;
    vector_ = other.vector_;
    return *this;
  }

  UnorderedSet(UnorderedSet<KeyT>&& other) {
    n_buckets_ = std::exchange(other.n_buckets_, 0);
    n_elements_ = std::exchange(other.n_elements_, 0);
    vector_ = std::move(other.vector_);
  }

  UnorderedSet& operator=(UnorderedSet&& other) {
    n_buckets_ = std::exchange(other.n_buckets_, 0);
    n_elements_ = std::exchange(other.n_elements_, 0);
    vector_ = std::vector<std::list<KeyT>>(1);
    vector_ = std::move(other.vector_);
    return *this;
  }

  size_t Size() const {
    return n_elements_;
  }

  bool Empty() const {
    return n_elements_ == 0;
  }

  void Clear() {
    vector_.clear();
    n_buckets_ = 0;
    n_elements_ = 0;
  }

  void Reserve(const size_t new_bucket_count) {
    if (new_bucket_count > n_buckets_) {
      Rehash(new_bucket_count);
    }
  }

  void Rehash(const size_t new_bucket_count) {
    if (new_bucket_count == n_buckets_ || new_bucket_count < n_elements_) {
      return;
    }
    std::vector<std::list<KeyT>> tmp(new_bucket_count);
    for (auto list : vector_) {
      if (!list.empty()) {
        while (!(list.empty())) {
          auto idx = hash(list.front()) % new_bucket_count;
          tmp[idx].push_front(list.front());
          list.pop_front();
        }
      }
    }
    n_buckets_ = new_bucket_count;
    vector_ = std::move(tmp);
  }

  void Insert(const KeyT& value) {
    if (n_buckets_ == 0) {
      vector_.resize(1);
      n_buckets_ = 1;
      n_elements_ = 0;
    }
    ++n_elements_;
    if (n_buckets_ < n_elements_) {
      Rehash(2 * n_buckets_);
    }
    auto idx = hash(value) % n_buckets_;
    vector_[idx].push_front(value);
  }

  void Insert(const KeyT&& value) {
    if (n_buckets_ == 0) {
      vector_.resize(1);
      n_buckets_ = 1;
      n_elements_ = 0;
    }
    ++n_elements_;
    if (n_buckets_ < n_elements_) {
      Rehash(2 * n_buckets_);
    }
    auto idx = hash(value) % n_buckets_;
    vector_[idx].push_front(std::move(value));
  }

  void Erase(const KeyT& value) {
    auto idx = hash(value) % n_buckets_;
    vector_[idx].remove(value);
    --n_elements_;
  }

  bool Find(const KeyT& value) const {
    if (n_buckets_ * n_elements_ == 0) {
      return false;
    }
    auto idx = hash(value) % n_buckets_;
    for (auto element : vector_[idx]) {
      if (element == value) {
        return true;
      }
    }
    return false;
  }

  [[nodiscard]] size_t BucketCount() const {
    return n_buckets_;
  }

  [[nodiscard]] size_t BucketSize(const size_t idx) const {
    if (n_buckets_ == 0 || idx >= n_buckets_) {
      return 0;
    }
    return vector_[idx].size();
  }

  [[nodiscard]] std::size_t Bucket(const KeyT key) const {
    if (n_buckets_ == 0) {
      return 0;
    }
    return hash(key) % n_buckets_;
  }

  [[nodiscard]] double LoadFactor() const {
    if (n_buckets_ == 0) {
      return 0;
    }
    return n_elements_ / (n_buckets_ * 1.0);
  }
};